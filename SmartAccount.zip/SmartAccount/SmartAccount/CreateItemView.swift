//
//  CreateItemView.swift
//  SmartAccount
//
//  Created by Paul Dexin Gong on 2025/10/13.
//

//import SwiftUI
//import SwiftData
//
//struct CreateItemView: View {
//    @Environment(\.dismiss) var dismiss
//    @Environment(\.modelContext) var modelContext
//    @State private var title: String = ""
//    @State private var notes: String = ""
//    @State private var value: Double = 0.0
//    @FocusState private var isTitleTextFieldFocused: Bool
//    @FocusState private var isNoteTextFieldFocused: Bool
//    @State private var hideNoteImage = false
//    @State private var isFlagged = false
//    var body: some View {
//        NavigationStack {
//            List {
//                Section("花费") {
//                    TextField("✏️名称", text: $title)
//                        .submitLabel(.next)
//                        .disableAutocorrection(false)
//                        .textInputAutocapitalization(.sentences)
//                        .focused($isTitleTextFieldFocused)
//                        .onSubmit {
//                            self.isNoteTextFieldFocused = true
//                        }
//                    TextField("金额",text: $value)
//                    VStack(alignment: .leading) {
//                        if !(hideNoteImage || isNoteTextFieldFocused) {
//                            Text("📝备注(可选)")
//                                .font(.headline)
//                                .foregroundColor(Color.gray.opacity(0.4))
//                        }
//                        TextEditor(text: $notes)
//                            .frame(minHeight: 30)
//                            .disableAutocorrection(false)
//                            .textInputAutocapitalization(.sentences)
//                            .focused($isNoteTextFieldFocused)
//                            .onTapGesture {
//                                hideNoteImage = true
//                            }
//                    }
//                }
//            }
//            .navigationTitle("记账")
//            .toolbar {
//                ToolbarItem(placement:.bottomBar) {
//                    Button {
//                        // saveItem()
//                    } label: {
//                        HStack {
//                            Image(systemName: "plus.circle.fill")
//                            Text("添加")
//                        }
//                    }
//                    .disabled(title.isEmpty)
//                }
//            }
//        }
//    }
//}
//
//#Preview {
//    CreateItemView()
//}
//
//extension CreateItemView {
//    private func saveItem() {
//        let item = Item()
//        item.title = title
//        item.notes = notes
//        item.value = value
//    }
//}

import SwiftUI
import SwiftData

struct CreateItemView: View {
    @Environment(\.dismiss) var dismiss
    @Environment(\.modelContext) var modelContext
    @State private var title: String = ""
    @State private var notes: String = ""
    @State private var valueString: String = "" // Use String for TextField binding
    @State private var value: Double = 0.0 // Keep Double for the actual value
    @FocusState private var isTitleTextFieldFocused: Bool
    @FocusState private var isNoteTextFieldFocused: Bool
    @State private var hideNoteImage = false
    @State private var isFlagged = false

    var body: some View {
        NavigationStack {
            List {
                Section("花费") {
                    TextField("✏️名称", text: $title)
                        .submitLabel(.next)
                        .disableAutocorrection(false)
                        .textInputAutocapitalization(.sentences)
                        .focused($isTitleTextFieldFocused)
                        .onSubmit {
                            self.isNoteTextFieldFocused = true
                        }
                    TextField("金额", text: $valueString)
                        .keyboardType(.decimalPad) // Use decimalPad for numeric input
                        .focused($isNoteTextFieldFocused)
                        .onChange(of: valueString) { newValue in
                            // Convert string to double as user types
                            if let doubleValue = Double(newValue) {
                                value = doubleValue
                            } else {
                                value = 0.0 // Fallback in case of invalid input
                            }
                        }
                    VStack(alignment: .leading) {
                        if !(hideNoteImage || isNoteTextFieldFocused) {
                            Text("📝备注(可选)")
                                .font(.headline)
                                .foregroundColor(Color.gray.opacity(0.4))
                        }
                        TextEditor(text: $notes)
                            .frame(minHeight: 30)
                            .disableAutocorrection(false)
                            .textInputAutocapitalization(.sentences)
                            .focused($isNoteTextFieldFocused)
                            .onTapGesture {
                                hideNoteImage = true
                            }
                    }
                }
            }
            .navigationTitle("记账")
            .toolbar {
                ToolbarItem(placement: .bottomBar) {
                    Button {
                        saveItem()
                    } label: {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                            Text("添加")
                        }
                    }
                    .disabled(title.isEmpty || valueString.isEmpty)
                }
            }
        }
    }

    private func saveItem() {
        let item = Item()
        item.title = title
        item.notes = notes
        item.value = value
        modelContext.insert(item) // Insert the item into the model context
        dismiss() // Dismiss the view after saving
    }
}

#Preview {
    CreateItemView()
}

