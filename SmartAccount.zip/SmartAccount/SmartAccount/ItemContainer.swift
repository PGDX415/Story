//
//  ThingsContainer.swift
//  SmartAccount
//
//  Created by Paul Dexin Gong on 2025/10/13.
//


import Foundation
import SwiftData

actor ItemContainer {
    @MainActor
    static func create() -> ModelContainer {
        ///Create container
        let schema = Schema([Item.self])
        let configuraton = ModelConfiguration()
        let container = try! ModelContainer(for: schema, configurations: configuraton)
        return container
    }
}
