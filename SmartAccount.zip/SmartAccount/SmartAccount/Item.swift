//
//  Item.swift
//  SmartAccount
//
//  Created by Paul Dexin Gong on 2025/10/13.
//

import Foundation
import SwiftData

@Model

final class Item {
    var id:String = UUID().uuidString
    var title = ""
    var notes = ""
    var spentDate = Date.now
    var isFlagged = false
    var value: Double = 0.0
    var payFrom = ""
    init(id: String = UUID().uuidString,
         title: String = "",
         notes: String = "",
         spentDate: Date = Date.now,
         isFlagged: Bool = false,
         value: Double = 0.0,
         payFrom: String = "")
    {
        self.id = id
        self.title = title
        self.notes = notes
        self.spentDate = spentDate
        self.isFlagged = isFlagged
        self.value = value
        self.payFrom = payFrom
    }
}
