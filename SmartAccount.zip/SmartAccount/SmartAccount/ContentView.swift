//
//  ContentView.swift
//  SmartAccount
//
//  Created by Paul Dexin Gong on 2025/10/13.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @Environment(\.dismiss) var dismiss
    @Environment(\.modelContext) var modelContext
    @State private var title: String = ""
    @State private var notes: String = ""
    @State private var valueString: String = "" // Use String for TextField binding
    @State private var value: Double = 0.0 // Keep Double for the actual value
    @FocusState private var isTitleTextFieldFocused: Bool
    @FocusState private var isNoteTextFieldFocused: Bool
    @State private var hideNoteImage = false
    @State private var isFlagged = false
  
    // MARK: within a day
    private var today: Date {
        Calendar.current.startOfDay(for: Date())
    }
    
    private var tomorrow: Date {
        Calendar.current.date(byAdding: .day, value: 1, to: today)!
    }
    
    private var yesterday: Date {
        Calendar.current.date(byAdding: .day, value: -1, to: today)!
    }
    
    private var startOfYesterday: Date {
        Calendar.current.startOfDay(for: yesterday)
    }
    
    @Query private var items: [Item]
    var itemsOfToday:[Item] {
        items.filter {
            $0.spentDate < tomorrow && $0.spentDate >= today
        }
    }
    
    var body: some View {
        NavigationStack {
            List {
                Section("花费") {
                    TextField("✏️名称", text: $title)
                        .submitLabel(.next)
                        .disableAutocorrection(false)
                        .textInputAutocapitalization(.sentences)
                        .focused($isTitleTextFieldFocused)
                        .onSubmit {
                            self.isNoteTextFieldFocused = true
                        }
                    TextField("金额", text: $valueString)
                        .keyboardType(.decimalPad) // Use decimalPad for numeric input
                        .focused($isNoteTextFieldFocused)
                        .onChange(of: valueString) { newValue in
                            // Convert string to double as user types
                            if let doubleValue = Double(newValue) {
                                value = doubleValue
                            } else {
                                value = 0.0 // Fallback in case of invalid input
                            }
                        }
                    VStack(alignment: .leading) {
                        if !(hideNoteImage || isNoteTextFieldFocused) {
                            Text("📝备注(可选)")
                                .font(.headline)
                                .foregroundColor(Color.gray.opacity(0.4))
                        }
                        TextEditor(text: $notes)
                            .frame(minHeight: 30)
                            .disableAutocorrection(false)
                            .textInputAutocapitalization(.sentences)
                            .focused($isNoteTextFieldFocused)
                            .onTapGesture {
                                hideNoteImage = true
                            }
                    }
                }
                ForEach(itemsOfToday) { item in
                    HStack {
                        VStack {
                            Text(item.title)
                                .bold()
                            Text(item.notes)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(String(item.value))
                    }
                }
            }
            .navigationTitle("记账")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        saveItem()
                    } label: {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                            Text("添加")
                        }
                    }
                    .disabled(title.isEmpty || valueString.isEmpty)
                }
            }
        }
    }
    private func saveItem() {
        let item = Item()
        item.title = title
        item.notes = notes
        item.value = value
        modelContext.insert(item) // Insert the item into the model context
        title = ""
        notes = ""
        valueString = ""
        value = 0.0
    }
}

#Preview {
    ContentView()
}
