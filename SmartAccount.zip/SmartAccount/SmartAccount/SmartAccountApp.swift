//
//  SmartAccountApp.swift
//  SmartAccount
//
//  Created by Paul Dexin Gong on 2025/10/13.
//

import SwiftUI
import SwiftData

@main
struct SmartAccountApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(ItemContainer.create())
    }
}
